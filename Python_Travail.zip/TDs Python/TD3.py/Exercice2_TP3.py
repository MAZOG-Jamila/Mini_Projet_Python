def somme_liste(liste):
    return sum(liste)

def moyenne_liste(liste):
    return somme_liste(liste) / len(liste)

nombres = [4, 8, 15, 16, 23, 42]
somme = somme_liste(nombres)
moyenne = moyenne_liste(nombres)

print("Somme des éléments :", somme)
print("Moyenne des éléments :", moyenne)
nombres = [7, 14, 21, 28, 35]
autres_nombres = [7, 11, 19, 24, 33]
def fusionner_et_trier(liste1, liste2):
    return sorted(liste1 +liste2)
resultat = fusionner_et_trier(nombres, autres_nombres)
print(resultat)
def element_existe(liste, element):
    return element in liste

nombres = [4, 8, 15, 16, 23, 42]

print(element_existe(nombres, 15))  # Résultat : True
print(element_existe(nombres, 50))  # Résultat : False
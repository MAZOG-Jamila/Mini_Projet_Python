def trouver_min_max(liste):
    return (min(liste), max(liste))

nombres = [4, 8, 15, 16, 23, 42]
min_max = trouver_min_max(nombres)
print("Minimum et Maximum :", min_max)
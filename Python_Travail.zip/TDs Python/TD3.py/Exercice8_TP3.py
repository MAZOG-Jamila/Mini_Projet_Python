def est_palindrome(mot ):
    return mot == mot[::-1]

mots = ["radar", "python", "level"]
for mot in mots:
    print(est_palindrome(mot))
nombres = [4, 8, 15, 16, 23, 42]

def affListe(lst):
    for element in lst:
        print(element)

# Test de la fonction
affListe(nombres)
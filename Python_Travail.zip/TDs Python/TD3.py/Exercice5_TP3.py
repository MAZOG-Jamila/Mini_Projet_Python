def liste_carres(liste):
    return [x**2 for x in liste]

nombres = [4, 8, 15, 16, 23, 42]
carres = liste_carres(nombres)

print("Liste des carrés :", carres)
def extraire_pairs(liste):
    return [x for x in liste if x % 2 == 0]

nombres = [4, 8, 15, 16, 23, 42]
pairs = extraire_pairs(nombres)

print("Liste des nombres pairs :", pairs)

###Calcul de la moyenne des notes
note_anglais = float(input("Saisir la note d'Anglais : "))
coefficient_anglais = float(input("Saisir le coefficient d'Anglais : "))

note_physique = float(input("Saisir la note de Physique : "))
coefficient_physique = float(input("Saisir le coefficient de Physique : "))

note_maths = float(input("Saisir la note de Maths : "))
coefficient_maths = float(input("Saisir le coefficient de Maths : "))

note_svt = float(input("Saisir la note de SVT : "))
coefficient_svt = float(input("Saisir le coefficient de SVT : "))

moyenne = (note_anglais * coefficient_anglais + note_physique * coefficient_physique + note_maths * coefficient_maths + note_svt * coefficient_svt) / (coefficient_anglais + coefficient_physique + coefficient_maths + coefficient_svt)

print("La moyenne des notes est : ", moyenne)

###Vérification du budget
budget = float(input("Saisir le budget : "))
achats = float(input("Saisir le montant des achats : "))

if budget >= achats:
    print("Le budget permet de payer les achats.")
else:
    print("Le budget ne permet pas de payer les achats.")
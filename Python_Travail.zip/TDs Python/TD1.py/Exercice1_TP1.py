#######TP1######

#EXERCICE1:
Str1, int1, dec1 = ("ceci est une chaîne", 12, 15.0)

print(type(Str1))
print(type(int1))
print(type(dec1))

nom, prenom, age = ("Park", "Tom", 30)

print(type(nom))
print(type(prenom))
print(type(age))



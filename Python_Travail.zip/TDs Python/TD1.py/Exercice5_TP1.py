phrase = input("Saisir une phrase : ")

longueur = len(phrase)

if longueur % 2 == 0:
    
    print(phrase[:longueur//2])
else:
    
    print(phrase[longueur//2 + 1:])
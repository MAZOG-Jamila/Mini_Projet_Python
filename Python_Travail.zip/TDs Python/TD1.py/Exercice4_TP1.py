import math

Rg = float(input("Saisir le rayon extérieur du disque : "))
Rp = float(input("Saisir le rayon intérieur du disque : "))

surface = math.pi * (Rg**2 - Rp**2)

print("La surface du disque découpé est : ", surface)
import math


rayon = float(input("Saisir le rayon du cône : "))
hauteur = float(input("Saisir la hauteur du cône : "))

volume = (1/3) * math.pi * (rayon**2) * hauteur

print("Le volume du cône est : ", volume)
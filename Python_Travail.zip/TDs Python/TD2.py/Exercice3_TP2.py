Matieres = ["Anglais", "Physique", "Maths", "Svt"]
print(Matieres)

Matieres = ["Anglais", "Physique", "Maths", "Svt"]
Matieres.append("Histoire")
Matieres.append("Geographie")
print(Matieres)

 
print(Matieres[:4])
print(Matieres[-3:])
print(Matieres[1:4])
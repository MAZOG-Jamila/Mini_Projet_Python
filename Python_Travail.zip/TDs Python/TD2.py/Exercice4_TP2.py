mylist = ['apple', 'banana', 'cherry']
mylist[0] = 'kiwi'
print(mylist[1]) # Résultat : banana

fruits = ["apple", "banana", "cherry"]
fruits[0] = 'kiwi'
print(fruits) # Résultat : ['kiwi', 'banana', 'cherry']

mylist = ['apple', 'banana', 'cherry']
mylist[1:2] = ['kiwi', 'mango']
print(mylist[2]) # Résultat : mango

mylist = ['apple', 'banana', 'cherry']
mylist.insert(0, 'orange')
print(mylist[1]) # Résultat : apple

fruits = ["apple", "banana", "cherry"]
fruits.append('orange')
print(fruits) # Résultat : ['apple', 'banana', 'cherry', 'orange']

fruits = ["apple", "banana", "cherry"]
fruits.insert(1, 'lemon')
print(fruits) # Résultat : ['apple', 'lemon', 'banana', 'cherry']
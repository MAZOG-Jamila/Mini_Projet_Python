Semaine = ['lun', 'mar', 'mer', 'jeu', 'ven', 'sam', 'dim']
Semaine.remove('mer')
print(Semaine) # Résultat : ['lun', 'mar', 'jeu', 'ven', 'sam', 'dim']

mylist = ['apple', 'banana', 'cherry']
mylist.pop(1)
print(mylist) # Résultat : ['apple', 'cherry']

fruits = ['apple', 'banana', 'cherry']
fruits.clear() # La fonction clear permet de vider la liste
print(fruits) # Résultat : []
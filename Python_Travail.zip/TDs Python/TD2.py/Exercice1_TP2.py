#1
Semaine = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"]
print(Semaine)
#2
Couleurs = ["Rouge", "Bleu", "Vert", "Jaune", "Orange"]
print(Couleurs)
#3
Reels = [1.2, 3.4, 5.6, 7.8, 9.0, 1.1, 2.2]
print(Reels[1], Reels[3], Reels[5])
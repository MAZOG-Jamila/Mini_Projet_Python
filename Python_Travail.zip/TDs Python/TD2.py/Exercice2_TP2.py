mylist = ['apple', 'banana', 'cherry']
print(mylist[1]) # Résultat : banana

mylist = ['apple', 'banana', 'banana', 'cherry']
print(mylist[2]) # Résultat : banana

thislist = ['apple', 'banana', 'cherry']
print(len(thislist)) # Résultat : 3

mylist = ['apple', 'banana', 'cherry']
print(mylist[-1]) # Résultat : cherry

fruits = ["apple", "banana", "cherry"]
print(fruits[1]) # Résultat : banana

mylist = ['apple', 'banana', 'cherry', 'orange', 'kiwi']
print(mylist[1:4]) # Résultat : ['banana', 'cherry', 'orange']

fruits = ["apple", "banana", "cherry", "orange", "kiwi", "melon", "mango"]
print(fruits[2:5]) # Résultat : ['cherry', 'orange', 'kiwi']
import numpy as np
import matplotlib.pyplot as plt

#  1
np.random.seed(0)
donnees = np.random.randn(100, 3)
matrice_covariance = np.cov(donnees.T)
print("Matrice de covariance :\n", matrice_covariance)

#  2
t = np.linspace(0, 1, 1000)
donnees_sinusoïdales = np.sin(2 * np.pi * 10 * t) + 0.5 * np.sin(2 * np.pi * 20 * t)
transformation_fourier = np.fft.fft(donnees_sinusoïdales)
spectre_frequences = np.abs(transformation_fourier)
freq = np.fft.fftfreq(len(t), d=0.001)

plt.figure(figsize=(10, 6))
plt.plot(freq, spectre_frequences)
plt.xlabel("Fréquence")
plt.ylabel("Amplitude")
plt.title("Spectre de fréquences")
plt.show()

#  3
lancers_de = np.random.randint(1, 7, size=(1000, 2))
sommes = np.sum(lancers_de, axis=1)

plt.figure(figsize=(10, 6))
plt.hist(sommes, bins=11, edgecolor="black")
plt.xlabel("Somme")
plt.ylabel("Fréquence")
plt.title("Histogramme des sommes obtenues")
plt.show()

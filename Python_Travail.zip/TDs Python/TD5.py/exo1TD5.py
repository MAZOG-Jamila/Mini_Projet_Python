import numpy as np

# Création des tableaux
tableau_1D = np.arange(10)
tableau_2D = np.random.rand(3, 3)
tableau_3D = np.zeros((2, 3, 4))
print("Tableau 1D:", tableau_1D)
print("\nTableau 2D:\n", tableau_2D)
print("\nTableau 3D:\n", tableau_3D)

# Accès aux éléments
troisieme_element = tableau_1D[2]
deuxieme_ligne_premiere_colonne = tableau_2D[1, 0]

# Modification d'un élément
tableau_3D[0, 1, 2] = 5
print("Tableau 3D modifié :\n", tableau_3D)

# Récupération des éléments
trois_premiers_elements = tableau_1D[:3]
derniere_colonne = tableau_2D[:, 2]

print("Tableau 1D :", tableau_1D)
print("Troisième élément :", troisieme_element)
print("Tableau 2D :\n", tableau_2D)
print("Deuxième ligne, première colonne :", deuxieme_ligne_premiere_colonne)
print("Tableau 3D :\n", tableau_3D)
print("Trois premiers éléments :", trois_premiers_elements)
print("Dernière colonne :", derniere_colonne)

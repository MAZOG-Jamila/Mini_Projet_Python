import numpy as np
# Création d'un tableau de 12 éléments
tableau = np.arange(12)
print("Tableau original :", tableau)

# Transformation en tableau 2D de dimensions (3, 4)
tableau_2D = tableau.reshape(3, 4)
print("Tableau 2D :", tableau_2D)

# Transformation en tableau 3D de dimensions (2, 2, 3)
tableau_3D = tableau.reshape(2, 2, 3)
print("Tableau 3D :\n", tableau_3D)

# Transposition du tableau 2D
tableau_2D_transpose = tableau_2D.T
print("Tableau 2D transposé :\n", tableau_2D_transpose)

# Échange des axes
tableau_2D_echange_axes = np.swapaxes(tableau_2D, 0, 1)
print("Tableau 2D avec échange des axes :\n", tableau_2D_echange_axes)

# Création de deux tableaux 2D de dimensions (2, 3)
tableau_A = np.arange(6).reshape(2, 3)
tableau_B = np.arange(6, 12).reshape(2, 3)

# Concaténation verticale
concat_vertical = np.concatenate((tableau_A, tableau_B), axis=0)
print("Concaténation verticale :\n", concat_vertical)

# Concaténation horizontale
concat_horizontal = np.concatenate((tableau_A, tableau_B), axis=1)
print("Concaténation horizontale :\n", concat_horizontal)

# Division en sous-tableaux
sous_tableau_A, sous_tableau_B = np.vsplit(concat_vertical, 2)
print("Sous-tableau A :\n", sous_tableau_A)
print("Sous-tableau B :\n", sous_tableau_B)
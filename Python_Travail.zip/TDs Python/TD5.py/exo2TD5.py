import numpy as np

# Création des tableaux
tableau1 = np.array([1, 2, 3, 4, 5])
tableau2 = np.array([6, 7, 8, 9, 10])
"""
# Opérations mathématiques élément par élément
addition = tableau1 + tableau2
soustraction = tableau1 - tableau2
multiplication = tableau1 * tableau2
division = tableau1 / tableau2

print("Addition :", addition)
print("Soustraction :", soustraction)
print("Multiplication :", multiplication)
print("Division :", division)

# Application des fonctions mathématiques
valeurs = np.linspace(0, np.pi, 10)
sinus = np.sin(valeurs)
cosinus = np.cos(valeurs)
exponentielle = np.exp(valeurs)

print("Sinus :", sinus)
print("Cosinus :", cosinus)
print("Exponentielle :", exponentielle)
"""
# Création d'un tableau d'entiers
entiers = np.arange(10)

# Sélection des éléments pairs
pairs = entiers[entiers % 2 == 0]
print("Éléments pairs :", pairs)

# Remplacement les éléments impairs par -1
entiers[entiers % 2 != 0] = -1
print("Entiers modifiés :", entiers)

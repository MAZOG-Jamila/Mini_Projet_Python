import numpy as np

#  1
tableau = np.random.rand(5, 5)
print("Tableau aléatoire :\n", tableau)

moyenne_ligne = np.mean(tableau, axis=1)
ecart_type_ligne = np.std(tableau, axis=1)
min_ligne = np.min(tableau, axis=1)
max_ligne = np.max(tableau, axis=1)

print("Moyenne par ligne :", moyenne_ligne)
print("Écart-type par ligne :", ecart_type_ligne)
print("Minimum par ligne :", min_ligne)
print("Maximum par ligne :", max_ligne)

moyenne_colonne = np.mean(tableau, axis=0)
ecart_type_colonne = np.std(tableau, axis=0)
min_colonne = np.min(tableau, axis=0)
max_colonne = np.max(tableau, axis=0)

print("Moyenne par colonne :", moyenne_colonne)
print("Écart-type par colonne :", ecart_type_colonne)
print("Minimum par colonne :", min_colonne)
print("Maximum par colonne :", max_colonne)

# 2
tableau_aleatoire = np.random.rand(10)
print("Tableau aléatoire :", tableau_aleatoire)

tableau_trie = np.sort(tableau_aleatoire)
print("Tableau trié :", tableau_trie)

indice_max = np.argmax(tableau_aleatoire)
print("Indice de l'élément maximum :", indice_max)

# 3
tableau_1D = np.array([1, 2, 3, 4])
print("Tableau 1D :", tableau_1D)

tableau_2D = np.array([[5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]])
print("Tableau 2D :\n", tableau_2D)

resultat = tableau_2D * tableau_1D
print("Résultat de la multiplication :\n", resultat)

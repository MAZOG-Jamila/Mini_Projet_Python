import numpy as np

# Création d'un tableau 2D de 12 mois x 3 produits avec valeurs aléatoires entre 100 et 1000
np.random.seed(42)  # Pour la reproductibilité
ventes = np.random.randint(100, 1000, size=(12, 3))
print("Tableau des ventes mensuelles (en unités):")
print(ventes)
#2
# Calcul du total annuel par produit
total_par_produit = np.sum(ventes, axis=0)
print("\nTotal annuel par produit:")
print(f"P1: {total_par_produit[0]}, P2: {total_par_produit[1]}, P3: {total_par_produit[2]}")
#3
# Calcul de la moyenne mensuelle par produit
moyenne_par_produit = np.mean(ventes, axis=0)
print("\nMoyenne mensuelle par produit:")
print(f"P1: {moyenne_par_produit[0]:.2f}, P2: {moyenne_par_produit[1]:.2f}, P3: {moyenne_par_produit[2]:.2f}")

#4
# Identification des mois avec ventes maximales
mois_max = np.argmax(ventes, axis=0) + 1  # +1 car les mois vont de 1 à 12
print("\nMois avec ventes maximales:")
print(f"P1: Mois {mois_max[0]}, P2: Mois {mois_max[1]}, P3: Mois {mois_max[2]}")

#5
# Calcul du taux de croissance mensuel
croissance = np.diff(ventes, axis=0) / ventes[:-1] * 100
print("\nTaux de croissance mensuel (%):")
print(croissance)

#6
# Identification des mois avec plus forte croissance
mois_croissance_max = np.argmax(croissance, axis=0) + 2  # +2 car diff déplace d'un mois
print("\nMois avec plus forte croissance:")
print(f"P1: Mois {mois_croissance_max[0]}, P2: Mois {mois_croissance_max[1]}, P3: Mois {mois_croissance_max[2]}")

#7
# Calcul du total des ventes tous produits confondus par mois
total_par_mois = np.sum(ventes, axis=1)
print("\nTotal des ventes par mois:")
print(total_par_mois)


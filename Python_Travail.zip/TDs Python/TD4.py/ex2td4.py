dict1={"a":1,"c":'AHMED'}
dict2={"c":'HI',"d":41}
dict3={}
def Fusionner_dictionnaires(dict1,dict2):
    dict3.update(dict1)
    dict3.update(dict2)
    return dict3
fusion=Fusionner_dictionnaires(dict1,dict2)
print(f"fusion des deux dictionnaire est: {fusion}")

def Trie_alphabitique(dict1):
    return{key:dict1[key]for key in sorted(dict1)}
def fusion3(dict1,dict2):
    for key in sorted(dict1):
     Trier=Trie_alphabitique(dict1)
     print(f"les clé trier par ordre:{Trier}")


fusion3(dict1,dict2)

def fusion3(dict1,dict2):
   for key in sorted(dict1):
       if key in dict2:
          if((type(dict1[key])is (int or float))) and((type(dict2[key])is(int or float))):
             dict3=dict1[key]+dict2[key]
       else:
         dict3=str(dict1[key]+str(dict2[key]))
       return dict3
dict3=(dict1,dict2)
print(dict3)
annuaire = {}

def ajouter_personne():
    personne = input("Entrez le nom et l'âge (Nom:Âge) : ")
    nom, age = personne.split(":")
    annuaire[nom] = int(age)
    print(f"{nom} ajouté(e) avec succès !")

def rechercher_personne():
    nom = input("Entrez le nom de la personne à rechercher : ")
    if nom in annuaire:
        print(f"{nom} a {annuaire[nom]} ans.")
    else:
        print(f"{nom} non trouvé(e) dans l'annuaire.")

def supprimer_personne():
    nom = input("Entrez le nom de la personne à supprimer : ")
    if nom in annuaire:
        del annuaire[nom]
        print(f"{nom} supprimé(e) avec succès !")
    else:
        print(f"{nom} non trouvé(e) dans l'annuaire.")

def afficher_annuaire():
    print("Annuaire :")
    for nom, age in annuaire.items():
        print(f"{nom} : {age} ans")

def main():
    while True:
        print("\nMenu :")
        print("1. Ajouter une personne")
        print("2. Rechercher une personne")
        print("3. Supprimer une personne")
        print("4. Afficher l'annuaire")
        print("5. Quitter")
        choix = input("Entrez votre choix : ")
        if choix == "1":
            ajouter_personne()
        elif choix == "2":
            rechercher_personne()
        elif choix == "3":
            supprimer_personne()
        elif choix == "4":
            afficher_annuaire()
        elif choix == "5":
            print("Au revoir !")
            break
        else:
            print("Choix invalide. Veuillez réessayer.")

if __name__ == "__main__":
    main()

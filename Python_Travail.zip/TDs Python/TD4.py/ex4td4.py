def analyser_notes(fichier):
    # Initialisation des variables
    notes = []
    total = 0
    
    # Lecture des données du fichier
    with open(fichier, 'r') as f:
        for ligne in f:
            nom, note = ligne.strip().split(',')
            notes.append((nom, int(note)))
            total += int(note)
    
    # Calcul de la note moyenne
    moyenne = total / len(notes)
    
    # Affichage des noms des étudiants ayant une note supérieure à la moyenne
    print("Étudiants ayant une note supérieure à la moyenne :")
    for nom, note in notes:
        if note > moyenne:
            print(f"{nom} : {note}")

# Appel de la fonction
analyser_notes('notes.txt')
class Etudiant:
    def __init__(self,nom,age,note):
       self.nom=nom 
       self.age=age
       self.note=note 
    def afficher_info(self):
       print(f"Nom :{self.nom},Age :{self.age},Note:{self.note}")
    @classmethod
    def moyenne_notes(cls,etudiants):
        return sum(etudiant.note for etudiant in etudiants)/len(etudiants)
etudiant1 =Etudiant("Tom",21,15)
etudiant2 =Etudiant("Maria",25,18)
etudiant3 =Etudiant("Adam",14,19)
etudiants =[etudiant1,etudiant2,etudiant3]
etudiant1.afficher_info()
etudiant2.afficher_info()
etudiant3.afficher_info()
print(f"Moyenne des notes:{Etudiant.moyenne_notes(etudiants):.2f}")

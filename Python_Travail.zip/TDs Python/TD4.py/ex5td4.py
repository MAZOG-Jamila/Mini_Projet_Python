class Etudiant:
    def __init__(self, nom, age, note):
        self.nom = nom
        self.age = age
        self.note = note

    def afficher_info(self):
        print(f"Nom : {self.nom}")
        print(f"Âge : {self.age} ans")
        print(f"Note : {self.note}/20")

    @staticmethod
    def calculer_moyenne(etudiants):
        total = sum(etudiant.note for etudiant in etudiants)
        return total / len(etudiants)

# Création d'objets Etudiant
etudiant1 = Etudiant("Jean", 20, 15)
etudiant2 = Etudiant("Marie", 22, 18)
etudiant3 = Etudiant("Pierre", 21, 12)

# Affichage des informations
etudiant1.afficher_info()
etudiant2.afficher_info()
etudiant3.afficher_info()

# Calcul de la moyenne
etudiants = [etudiant1, etudiant2, etudiant3]
moyenne = Etudiant.calculer_moyenne(etudiants)
print(f"Moyenne des notes : {moyenne:.2f}/20")
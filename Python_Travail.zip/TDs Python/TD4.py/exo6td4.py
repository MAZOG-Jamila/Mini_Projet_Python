class CarnetAdresses:
    def __init__(self):
        self.contacts = {}

    def ajouter_contact(self, nom, email, telephone):
        self.contacts[nom] = {"email": email, "telephone": telephone}

    def supprimer_contact(self, nom):
        self.contacts.pop(nom, None)

    def rechercher_contact(self, nom):
        return self.contacts.get(nom, "Contact non trouvé")

    def afficher_contacts(self):
        return self.contacts
    
    def sauvegarder_contacts(self, fichier):
        with open(fichier, "w", newline="") as f:
            for nom, infos in self.contacts.items():
                email = infos["email"]
                telephone = infos["telephone"]
                f.write(f"{nom},{email},{telephone}\n")

# Test du programme
carnet = CarnetAdresses()
carnet.ajouter_contact("Maria", "mariaem@gmail.com", "0612151382")
carnet.ajouter_contact("Tom", "tomjmh@gmail.com", "079123415")

print(carnet.rechercher_contact("Maria"))
print("\n", carnet.afficher_contacts())

carnet.supprimer_contact("Maria")
print("\n", carnet.afficher_contacts())

carnet.sauvegarder_contacts("contacts.txt")

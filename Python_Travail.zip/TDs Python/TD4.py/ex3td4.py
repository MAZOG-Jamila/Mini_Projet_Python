def fusionner_dictionnaires(d1, d2):
    d_fusionne = {**d1, **d2}
    
    for cle in d1:
        if cle in d2:
            if isinstance(d1[cle], (int, float)) and isinstance(d2[cle], (int, float)):
                d_fusionne[cle] = d1[cle] + d2[cle]
            elif isinstance(d1[cle], str) and isinstance(d2[cle], str):
                d_fusionne[cle] = d1[cle] + d2[cle]
    
    d_fusionne = dict(sorted(d_fusionne.items()))
    
    return d_fusionne

# Exemple d'utilisation
d1 = {"a": 10, "b": "test"}
d2 = {"a": 5, "c": "data"}

resultat = fusionner_dictionnaires(d1, d2)
print(resultat)  # Résultat : {"a": 15, "b": "test", "c": "data"}
class Livre:
    def __init__(self, titre, auteur):
        self.titre = titre
        self.auteur = auteur
        self.statut = "disponible"

class Bibliotheque:
    def __init__(self):
        self.livres = []

    def ajouter_livre(self, livre):
        self.livres.append(livre)

    def emprunter_livre(self, titre):
        for livre in self.livres:
            if livre.titre == titre:
                if livre.statut == "disponible":
                    livre.statut = "emprunté"
                    print(f"Le livre '{titre}' a été emprunté.")
                else:
                    print(f"Le livre '{titre}' est déjà emprunté.")
                return
        print(f"Le livre '{titre}' n'a pas été trouvé.")

    def rendre_livre(self, titre):
        for livre in self.livres:
            if livre.titre == titre:
                if livre.statut == "emprunté":
                    livre.statut = "disponible"
                    print(f"Le livre '{titre}' a été rendu.")
                else:
                    print(f"Le livre '{titre}' est déjà disponible.")
                return
        print(f"Le livre '{titre}' n'a pas été trouvé.")

    def lister_livres_disponibles(self):
        print("Livres disponibles :")
        for livre in self.livres:
            if livre.statut == "disponible":
                print(livre.titre)

biblio = Bibliotheque()

livre1 = Livre("Livre 1", "Auteur 1")
livre2 = Livre("Livre 2", "Auteur 2")
biblio.ajouter_livre(livre1)
biblio.ajouter_livre(livre2)

biblio.emprunter_livre("Livre 1")

biblio.rendre_livre("Livre 1")

biblio.lister_livres_disponibles()
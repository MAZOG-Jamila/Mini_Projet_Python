with open("note-etudiants.txt","w")as file:
    file.write("Tom,20\n")
    file.write("Mery,15\n")
    file.write("Liley,12 \n")
with open("note-etudiants.txt","r")as file:
    Notes=[]
    Noms=[]
    for ligne in file:
        Nom,Note=ligne.strip().split(",")
        Note=int(Note)
        Noms.append(Nom)
        Notes.append(Note)
        Moyenne=sum(Notes)/len(Notes)
print(f"la note moyenne est:{Moyenne:.2f}")
print("\n Etudians avec une note superieur a la moyenne:")
for nom,note in zip(Noms,Notes):
            if note>Moyenne:
                  print(Nom)